const c = 'pwa-cache', f = ['/', '/index.html'];
self.addEventListener('install', e => e.waitUntil(caches.open(c).then(x => x.addAll(f))));
self.addEventListener('fetch', e => e.respondWith(caches.match(e.request).then(r => r ||
fetch(e.request))));