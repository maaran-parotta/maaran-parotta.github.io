
import { add, multiply, isEven } from './math.js';

test('adds numbers correctly', () => {
  expect(add(2, 3)).toBe(5);
});

test('multiplies numbers correctly', () => {
  expect(multiply(2, 3)).toBe(6);
});

test('checks if number is even', () => {
  expect(isEven(4)).toBe(true);
  expect(isEven(5)).toBe(false);
});
