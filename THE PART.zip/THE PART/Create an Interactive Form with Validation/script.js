document.getElementById('signupForm').addEventListener('submit', function(event) {
  event.preventDefault();
  const name = document.getElementById('name').value.trim();
  const email = document.getElementById('email').value.trim();
  const password = document.getElementById('password').value.trim();
  const message = document.getElementById('message');

  
  if (name === '' || email === '' || password === '') {
    message.textContent = 'Please fill out all fields.';
    message.style.color = 'red';
    return;
  }

  
  const emailPattern = /^[^ ]+@[^ ]+\.[a-z]{2,3}$/;
  if (!email.match(emailPattern)) {
    message.textContent = 'Please enter a valid email address.';
    message.style.color = 'red';
    return;
  }

  
  if (password.length < 6) {
    message.textContent = 'Password must be at least 6 characters.';
    message.style.color = 'red';
    return;
  }

  
  message.textContent = 'Form submitted successfully!';
  message.style.color = 'green';

  
  alert('🎉 Form submitted successfully!');

  
  document.getElementById('signupForm').reset();
});
