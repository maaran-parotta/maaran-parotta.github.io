
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('service-worker.js')
      .then(() => console.log('Service Worker Registered ✅'))
      .catch(err => console.error('SW registration failed:', err));
  });
}


document.getElementById('actionBtn').addEventListener('click', () => {
  const msg = document.getElementById('message');
  msg.textContent = 'PWA is working perfectly offline! 🎉';
  msg.style.color = '#0066cc';
});
